from typing import Optional, Any

from beanie import Document
from pydantic import BaseModel, EmailStr

class User(Document):
    firstName: str
    lastName: str
    email: EmailStr
    password:str
    role:str
    emailVerified:bool
    mobileVerified:bool
    subscribed:bool 
    subscriptionType: bool
    class Config:
        json_schema_extra = {
            "example": {
                "fullname": "Abdulazeez Abdulazeez Adeshina",
                "email": "abdul@school.com",
                "course_of_study": "Water resources engineering",
                "year": 4,
                "gpa": "3.76",
            }
        }

    class Settings:
        name = "users"
        
__all__ = [User]